package com.example.demo.subcontroller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.common.dto.CommonRequest;
import com.example.demo.subtract.Subtract;

@RestController
public class SubController 
{
	@Autowired
	private Subtract sub;
	
	@RequestMapping(value = "/sub", method = RequestMethod.POST)
	public ResponseEntity<?> math(@Valid @RequestBody CommonRequest request)
	{
		return sub.operation(request);
	}
}
