package com.example.demo.subtract;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.common.dto.CommonRequest;
import com.example.demo.subservice.SubService;

@Service
public class Subtract
{
	@Autowired
	private SubService service;
	
	public ResponseEntity<?> operation(CommonRequest request)
	{
		return service.service(request.getNum1(),request.getNum2());
		
	}
}
