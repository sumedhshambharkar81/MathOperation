package com.example.demo.subservice;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public interface SubService
{
	public ResponseEntity<?> service(String num1,String num2);
}
