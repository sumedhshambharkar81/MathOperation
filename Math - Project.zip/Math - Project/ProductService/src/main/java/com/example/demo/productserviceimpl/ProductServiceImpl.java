package com.example.demo.productserviceimpl;

import org.apache.commons.math3.util.Precision;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.common.dto.CommonResponse;
import com.example.demo.productservice.ProductService;

@Component
public class ProductServiceImpl implements ProductService
{

	@Override
	public ResponseEntity<?> service(String num1, String num2)
	{
		Integer product = Integer.parseInt(num1) * Integer.parseInt(num2) ;
		CommonResponse response = new CommonResponse(Precision.round(product.doubleValue(), 2));
		return ResponseEntity.ok(response);

	}

}
