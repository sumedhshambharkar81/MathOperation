package com.example.demo.productservice;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public interface ProductService 
{
	public ResponseEntity<?> service(String num1,String num2);
}
