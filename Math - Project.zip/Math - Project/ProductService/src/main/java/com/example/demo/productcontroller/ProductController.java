package com.example.demo.productcontroller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.common.dto.CommonRequest;
import com.example.demo.product.Product;

@RestController
public class ProductController 
{
	@Autowired
	private Product prod;
	
	@RequestMapping(value = "/prod", method = RequestMethod.POST)
	public ResponseEntity<?> math(@Valid @RequestBody CommonRequest request)
	{
		return prod.operation(request);
	}
}
