package com.example.demo.divisionservice;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public interface DivisionService 
{

	public ResponseEntity<?> service(String num1, String num2);

}
