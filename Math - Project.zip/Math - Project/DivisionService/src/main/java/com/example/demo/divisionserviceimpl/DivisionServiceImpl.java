package com.example.demo.divisionserviceimpl;

import org.apache.commons.math3.util.Precision;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.common.dto.CommonResponse;
import com.example.demo.divisionservice.DivisionService;

@Component
public class DivisionServiceImpl implements DivisionService
{

	@Override
	public ResponseEntity<?> service(String num1, String num2)
	{
		Float division = (float) Integer.parseInt(num1) / Integer.parseInt(num2);
		CommonResponse response = new CommonResponse(Precision.round( division.doubleValue(),2));
		return ResponseEntity.ok(response);
	}

}
																																																																