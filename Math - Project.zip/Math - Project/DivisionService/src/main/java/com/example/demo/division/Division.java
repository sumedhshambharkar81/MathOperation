package com.example.demo.division;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.common.dto.CommonRequest;
import com.example.demo.divisionservice.DivisionService;

@Service
public class Division 
{
	@Autowired
	private DivisionService service;
	
	public ResponseEntity<?> operation(CommonRequest request)
	{
		return service.service(request.getNum1(),request.getNum2());
		
	}
}
