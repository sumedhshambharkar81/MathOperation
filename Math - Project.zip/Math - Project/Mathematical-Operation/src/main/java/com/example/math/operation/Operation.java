package com.example.math.operation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.common.dto.CommonRequest;
import com.common.dto.CommonResponse;
import com.example.math.dto.ResponseDTO;


@Service 
public class Operation 
{
	
	@Value("${url_name_sum}")
	private  String url_sum;
	
	@Value("${url_name_sub}")
	private String url_sub;
	
	@Value("${url_name_prod}")
	private String url_prod;
	
	@Value("${url_name_div}")
	private String url_div;
	
	@Autowired
	private ResponseDTO response;
	
	CommonResponse res = new CommonResponse();
	
	
	public ResponseEntity<?> operation(CommonRequest request)
	{
	
		RestTemplate rst =  new RestTemplate();
			
		res = rst.postForObject(url_sum, request,CommonResponse.class);
		response.setSum(res.getResponse());
		
		res = rst.postForObject(url_sub, request,CommonResponse.class);
		response.setSub(res.getResponse());
		
		res = rst.postForObject(url_prod, request,CommonResponse.class);
		response.setProduct(res.getResponse());
		
		res = rst.postForObject(url_div, request,CommonResponse.class);
		response.setDivision(res.getResponse());
		
		return ResponseEntity.ok(response);
		
	}
	
}
