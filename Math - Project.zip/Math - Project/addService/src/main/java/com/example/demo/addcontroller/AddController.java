package com.example.demo.addcontroller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.common.dto.CommonRequest;
import com.example.demo.addition.Addition;

@RestController
public class AddController 
{
	@Autowired
	private Addition sub;
	
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public ResponseEntity<?> math(@Valid @RequestBody CommonRequest request)
	{
		return sub.operation(request);
	}
}
