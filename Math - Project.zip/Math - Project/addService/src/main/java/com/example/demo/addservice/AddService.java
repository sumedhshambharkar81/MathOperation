package com.example.demo.addservice;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public interface AddService
{
	public ResponseEntity<?> service(String num1,String num2);
}
