package com.example.demo.addition;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.common.dto.CommonRequest;
import com.example.demo.addservice.AddService;

@Service
public class Addition
{
	@Autowired
	private AddService service;
	
	public ResponseEntity<?> operation(CommonRequest request)
	{
		return service.service(request.getNum1(),request.getNum2());
		
	}
}
